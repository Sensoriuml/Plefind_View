package com.android.plefind.plefindview;

import java.util.Date;

public class TableRow {
    private Date birthdate;
    private String diagnosis;
    private String hardware;
    private boolean healthy;
    private String height;
    private String lung;
    private String notes;
    private String sex;
    private String software;
    private String weight;
    private String objectID;

    public TableRow(Date birthdate, String diagnosis, String hardware, boolean healthy, String height, String lung, String notes, String sex, String software, String weight, String objectID, String name) {
        this.birthdate = birthdate;
        this.diagnosis = diagnosis;
        this.hardware = hardware;
        this.healthy = healthy;
        this.height = height;
        this.lung = lung;
        this.notes = notes;
        this.sex = sex;
        this.software = software;
        this.weight = weight;
        this.objectID = objectID;
        this.name = name;
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getHardware() {
        return hardware;
    }

    public void setHardware(String hardware) {
        this.hardware = hardware;
    }

    public boolean isHealthy() {
        return healthy;
    }

    public void setHealthy(boolean healthy) {
        this.healthy = healthy;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getLung() {
        return lung;
    }

    public void setLung(String lung) {
        this.lung = lung;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSoftware() {
        return software;
    }

    public void setSoftware(String software) {
        this.software = software;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getObjectID() {
        return objectID;
    }

    public void setObjectID(String objectID) {
        this.objectID = objectID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;
}
