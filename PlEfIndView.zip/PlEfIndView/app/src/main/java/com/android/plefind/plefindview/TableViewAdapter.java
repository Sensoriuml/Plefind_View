package com.android.plefind.plefindview;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class TableViewAdapter extends RecyclerView.Adapter {
    List<TableRow> tableRowList;

    public TableViewAdapter(List<TableRow> tableRowList) {
        this.tableRowList = tableRowList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.
                from(parent.getContext()).
                inflate(R.layout.table_list_item, parent, false);

        return new RowViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        RowViewHolder rowViewHolder = (RowViewHolder) holder;
        int rowPos = rowViewHolder.getAdapterPosition();

        if (rowPos == 0) {
            // Header Cells. Main Headings appear here
            rowViewHolder.txtSelect.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.txtName.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.txtNotes.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.txtDiagnosis.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.txtPleuralEffusion.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.txtLung.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.txtSex.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.txtAge.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.txtHeight.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.txtWeight.setBackgroundResource(R.drawable.table_header_cell_bg);

            rowViewHolder.txtSelect.setText("");
            rowViewHolder.txtName.setText("Name");
            rowViewHolder.txtNotes.setText("Notes");
            rowViewHolder.txtDiagnosis.setText("Diagnosis");
            rowViewHolder.txtPleuralEffusion.setText("Pleural effusion");
            rowViewHolder.txtLung.setText("Lung");
            rowViewHolder.txtSex.setText("Sex");
            rowViewHolder.txtAge.setText("Birthdate");
            rowViewHolder.txtHeight.setText("Height");
            rowViewHolder.txtWeight.setText("Weight");
        } else {
            TableRow tableRow = tableRowList.get(rowPos-1);

            // Content Cells. Content appear here
            rowViewHolder.txtSelect.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.txtName.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.txtNotes.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.txtDiagnosis.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.txtPleuralEffusion.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.txtLung.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.txtSex.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.txtAge.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.txtHeight.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.txtWeight.setBackgroundResource(R.drawable.table_content_cell_bg);

            rowViewHolder.txtSelect.setText("");
            rowViewHolder.txtName.setText(tableRow.getName());
            rowViewHolder.txtNotes.setText(tableRow.getNotes());
            rowViewHolder.txtDiagnosis.setText(tableRow.getDiagnosis());
            rowViewHolder.txtPleuralEffusion.setText(Boolean.toString(tableRow.isHealthy()));
            rowViewHolder.txtLung.setText(tableRow.getLung());
            rowViewHolder.txtSex.setText(tableRow.getSex());
            rowViewHolder.txtAge.setText(tableRow.getBirthdate().toString());
            rowViewHolder.txtHeight.setText(tableRow.getHeight());
            rowViewHolder.txtWeight.setText(tableRow.getWeight());
        }
    }

    @Override
    public int getItemCount() {
        return tableRowList.size()+1; // one more to add header row
    }

    public class RowViewHolder extends RecyclerView.ViewHolder {
        protected TextView txtSelect, txtName, txtNotes, txtDiagnosis, txtPleuralEffusion, txtLung,
                txtSex, txtAge, txtHeight, txtWeight;

        public RowViewHolder(View itemView) {
            super(itemView);

            txtSelect = itemView.findViewById(R.id.txtSelect);
            txtName = itemView.findViewById(R.id.txtName);
            txtNotes = itemView.findViewById(R.id.txtNotes);
            txtDiagnosis = itemView.findViewById(R.id.txtDiagnosis);
            txtPleuralEffusion = itemView.findViewById(R.id.txtPleuralEffusion);
            txtLung = itemView.findViewById(R.id.txtLung);
            txtSex = itemView.findViewById(R.id.txtSex);
            txtAge = itemView.findViewById(R.id.txtAge);
            txtHeight = itemView.findViewById(R.id.txtHeight);
            txtWeight = itemView.findViewById(R.id.txtWeight);
        }
    }
}