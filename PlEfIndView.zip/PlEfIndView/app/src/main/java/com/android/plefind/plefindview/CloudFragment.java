package com.android.plefind.plefindview;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.backendless.persistence.DataQueryBuilder;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class CloudFragment extends Fragment {

    private Context context;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        context = getContext();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cloud, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ScrollView scrollView = view.findViewById(R.id.scrollViewCloud);
        HorizontalScrollView horizontalScrollView = new HorizontalScrollView(context);
        scrollView.addView(horizontalScrollView);

        RecyclerView recyclerView = new RecyclerView(context);
        recyclerView.setNestedScrollingEnabled(false);
        horizontalScrollView.addView(recyclerView);

        TableViewAdapter adapter = new TableViewAdapter(getTable());

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setAdapter(adapter);
    }

    private List<TableRow> getTable(){
        final List<TableRow> table = new ArrayList<>();

        Backendless.Data.of( "LABdata" ).getObjectCount(new AsyncCallback<Integer>()
        {
            @Override
            public void handleResponse( Integer integer )
            {
                Log.i( "MYAPP", "total objects in the Order table - " + integer );
            }

            @Override
            public void handleFault( BackendlessFault backendlessFault )
            {
                Log.i( "MYAPP", "error - " + backendlessFault.getMessage() );
            }
        } );

        DataQueryBuilder queryBuilder = DataQueryBuilder.create();
        queryBuilder.setSortBy( "created DESC" );
        Backendless.Data.of( "LABdata" ).find( queryBuilder,
                new AsyncCallback<List<Map>>()
                {
                    @Override
                    public void handleResponse( List<Map> response )
                    {
                        System.out.println(response.size());
                        for(Map object : response){
                            String sex = null;
                            if (object.get("Sex").toString() == "F")
                                sex = "Female";
                            else if (object.get("Sex").toString() == "M")
                                sex = "Male";
                            String lung = null;
                            if (object.get("Lung").toString() == "R")
                                lung = "Right";
                            else if (object.get("Lung").toString() == "L")
                                lung = "Left";
                            //System.out.println(object.get("name")+"\n");
                            table.add(new TableRow((Date) object.get("age"),
                                    object.get("diagnosis").toString(),
                                    object.get("hardware").toString(),
                                    (Boolean) object.get("Healthy"),
                                    object.get("height").toString(),
                                    lung,
                                    object.get("notes").toString(),
                                    sex,
                                    object.get("software").toString(),
                                    object.get("weight").toString(),
                                    object.get("objectId").toString(),
                                    object.get("name").toString()));
                        }
                    }

                    @Override
                    public void handleFault( BackendlessFault fault )
                    {
                        System.out.println(fault.getMessage());
                    }
                });

        return table;
    }

}
